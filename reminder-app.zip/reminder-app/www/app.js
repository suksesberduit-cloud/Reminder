// app.js — jembatan UI ke plugin native ReminderPlugin
// Plugin native ini yang menjalankan Foreground Service pendeteksi unlock layar.

const appSelect = document.getElementById('appSelect');
const customPkgWrap = document.getElementById('customPkgWrap');
const customPkg = document.getElementById('customPkg');
const masterToggle = document.getElementById('masterToggle');
const notifTitle = document.getElementById('notifTitle');
const notifBody = document.getElementById('notifBody');
const saveBtn = document.getElementById('saveBtn');
const statusText = document.getElementById('statusText');

const STORAGE_KEY = 'reminder_config_v1';

function loadConfig() {
  const raw = localStorage.getItem(STORAGE_KEY);
  return raw ? JSON.parse(raw) : {
    enabled: false,
    targetPackage: 'com.google.android.apps.books',
    title: 'Waktunya fokus baca 📚',
    body: 'Ketuk untuk lanjut baca bukumu',
  };
}

function applyConfigToUI(cfg) {
  masterToggle.checked = cfg.enabled;
  notifTitle.value = cfg.title;
  notifBody.value = cfg.body;

  const known = Array.from(appSelect.options).some(o => o.value === cfg.targetPackage);
  if (known && cfg.targetPackage !== 'custom') {
    appSelect.value = cfg.targetPackage;
    customPkgWrap.style.display = 'none';
  } else {
    appSelect.value = 'custom';
    customPkg.value = cfg.targetPackage;
    customPkgWrap.style.display = 'block';
  }
}

appSelect.addEventListener('change', () => {
  customPkgWrap.style.display = appSelect.value === 'custom' ? 'block' : 'none';
});

async function callNativePlugin(method, options = {}) {
  // Capacitor auto-generates window.Capacitor.Plugins.Reminder dari ReminderPlugin.kt
  const plugin = window.Capacitor?.Plugins?.Reminder;
  if (!plugin) {
    console.warn('Plugin native Reminder belum tersedia (jalan di browser biasa?)');
    return null;
  }
  return plugin[method](options);
}

saveBtn.addEventListener('click', async () => {
  const targetPackage = appSelect.value === 'custom' ? customPkg.value.trim() : appSelect.value;
  const cfg = {
    enabled: masterToggle.checked,
    targetPackage,
    title: notifTitle.value.trim() || 'Reminder',
    body: notifBody.value.trim() || 'Ketuk untuk membuka aplikasi',
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));

  if (cfg.enabled) {
    // Minta izin notifikasi + battery optimization (dialog transparan ke user)
    await callNativePlugin('requestPermissions');
    await callNativePlugin('startService', cfg);
    statusText.textContent = 'Status: Aktif — memantau unlock layar';
  } else {
    await callNativePlugin('stopService');
    statusText.textContent = 'Status: Nonaktif';
  }
});

(async function init() {
  const cfg = loadConfig();
  applyConfigToUI(cfg);
  const running = await callNativePlugin('isRunning');
  statusText.textContent = running?.value
    ? 'Status: Aktif — memantau unlock layar'
    : 'Status: Nonaktif';
})();
