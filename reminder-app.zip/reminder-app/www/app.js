// app.js — jembatan UI ke plugin native ReminderPlugin

const pickAppBtn = document.getElementById('pickAppBtn');
const selectedAppText = document.getElementById('selectedAppText');
const a11yBtn = document.getElementById('a11yBtn');
const a11yStatusText = document.getElementById('a11yStatusText');
const masterToggle = document.getElementById('masterToggle');
const notifTitle = document.getElementById('notifTitle');
const notifBody = document.getElementById('notifBody');
const saveBtn = document.getElementById('saveBtn');
const statusText = document.getElementById('statusText');

const STORAGE_KEY = 'reminder_config_v1';

function loadConfig() {
  const raw = localStorage.getItem(STORAGE_KEY);
  return raw ? JSON.parse(raw) : {
    enabled: false,
    targetPackage: '',
    targetAppName: '',
    title: 'Waktunya fokus baca 📚',
    body: 'Ketuk untuk lanjut baca bukumu',
  };
}

let currentConfig = loadConfig();

function renderSelectedApp() {
  selectedAppText.textContent = currentConfig.targetAppName
    ? currentConfig.targetAppName + ' (' + currentConfig.targetPackage + ')'
    : 'Belum ada aplikasi dipilih';
}

function applyConfigToUI() {
  masterToggle.checked = currentConfig.enabled;
  notifTitle.value = currentConfig.title;
  notifBody.value = currentConfig.body;
  renderSelectedApp();
}

async function callNativePlugin(method, options) {
  options = options || {};
  const plugin = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Reminder;
  if (!plugin) {
    console.warn('Plugin native Reminder belum tersedia (jalan di browser biasa?)');
    return null;
  }
  return plugin[method](options);
}

async function refreshA11yStatus() {
  const res = await callNativePlugin('isAccessibilityEnabled');
  a11yStatusText.textContent = (res && res.value)
    ? 'Accessibility: ✅ Aktif'
    : 'Accessibility: ❌ Belum aktif';
}

a11yBtn.addEventListener('click', async () => {
  await callNativePlugin('openAccessibilitySettings');
});

document.addEventListener('visibilitychange', () => {
  if (!document.hidden) refreshA11yStatus();
});

pickAppBtn.addEventListener('click', async () => {
  try {
    const result = await callNativePlugin('pickInstalledApp');
    if (result && result.packageName) {
      currentConfig.targetPackage = result.packageName;
      currentConfig.targetAppName = result.appName;
      renderSelectedApp();
    }
  } catch (e) {
    console.log('Pemilihan app dibatalkan:', e);
  }
});

saveBtn.addEventListener('click', async () => {
  currentConfig.enabled = masterToggle.checked;
  currentConfig.title = notifTitle.value.trim() || 'Reminder';
  currentConfig.body = notifBody.value.trim() || 'Ketuk untuk membuka aplikasi';

  if (currentConfig.enabled && !currentConfig.targetPackage) {
    statusText.textContent = 'Status: Pilih aplikasi tujuan dulu';
    return;
  }

  localStorage.setItem(STORAGE_KEY, JSON.stringify(currentConfig));

  if (currentConfig.enabled) {
    await callNativePlugin('requestPermissions');
    await callNativePlugin('startService', currentConfig);
    statusText.textContent = 'Status: Aktif — memantau unlock layar';
  } else {
    await callNativePlugin('stopService');
    statusText.textContent = 'Status: Nonaktif';
  }
});

(async function init() {
  applyConfigToUI();
  refreshA11yStatus();
  const running = await callNativePlugin('isRunning');
  statusText.textContent = (running && running.value)
    ? 'Status: Aktif — memantau unlock layar'
    : 'Status: Nonaktif';
})();
