package id.reminder.app

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Foreground service ringan yang mendaftarkan BroadcastReceiver untuk
 * ACTION_USER_PRESENT (layar dibuka kunci) secara runtime.
 * Wajib runtime-register karena Android melarang manifest-static receiver
 * untuk ACTION_SCREEN_ON/OFF/USER_PRESENT sejak Android 3.1+.
 */
class ScreenUnlockService : Service() {

    private lateinit var unlockReceiver: BroadcastReceiver
    private val CHANNEL_ID = "reminder_service_channel"
    private val NOTIF_CHANNEL_TRIGGER = "reminder_trigger_channel"
    private val SERVICE_NOTIF_ID = 9001
    private val TRIGGER_NOTIF_ID = 9002

    override fun onCreate() {
        super.onCreate()
        createChannels()
        startForeground(SERVICE_NOTIF_ID, buildServiceNotification())

        unlockReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (intent.action == Intent.ACTION_USER_PRESENT) {
                    fireReminderNotification()
                }
            }
        }
        registerReceiver(unlockReceiver, IntentFilter(Intent.ACTION_USER_PRESENT))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // START_STICKY: minta sistem restart service kalau di-kill (RAM rendah dsb)
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(unlockReceiver) } catch (_: Exception) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)

            val serviceChannel = NotificationChannel(
                CHANNEL_ID, "Status Reminder", NotificationManager.IMPORTANCE_MIN
            )
            mgr.createNotificationChannel(serviceChannel)

            val triggerChannel = NotificationChannel(
                NOTIF_CHANNEL_TRIGGER, "Notifikasi Reminder", NotificationManager.IMPORTANCE_HIGH
            )
            mgr.createNotificationChannel(triggerChannel)
        }
    }

    /** Notifikasi permanen kecil — transparan bahwa service sedang berjalan. */
    private fun buildServiceNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Reminder aktif")
            .setContentText("Memantau saat layar dibuka kunci")
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
    }

    /** Notifikasi yang muncul tiap kali layar unlock. Tap -> buka app target. */
    private fun fireReminderNotification() {
        val prefs = getSharedPreferences("reminder_prefs", 0)
        if (!prefs.getBoolean("enabled", false)) return

        val targetPackage = prefs.getString("targetPackage", "") ?: ""
        val title = prefs.getString("title", "Reminder") ?: "Reminder"
        val body = prefs.getString("body", "Ketuk untuk membuka aplikasi") ?: ""

        val launchIntent = packageManager.getLaunchIntentForPackage(targetPackage)
            ?: Intent(Intent.ACTION_VIEW, android.net.Uri.parse("market://details?id=$targetPackage"))
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        val pendingIntent = PendingIntent.getActivity(
            this, TRIGGER_NOTIF_ID, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(this, NOTIF_CHANNEL_TRIGGER)
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val mgr = getSystemService(NotificationManager::class.java)
        mgr.notify(TRIGGER_NOTIF_ID, notif)
    }
}
