package id.reminder.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Receiver ini BOLEH didaftarkan statis di manifest (beda dengan ACTION_USER_PRESENT)
 * karena BOOT_COMPLETED memang salah satu broadcast yang diizinkan manifest-static.
 * Hanya menyalakan ulang service jika user sebelumnya mengaktifkan reminder.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val enabled = context.getSharedPreferences("reminder_prefs", 0)
                .getBoolean("enabled", false)
            if (!enabled) return

            val serviceIntent = Intent(context, ScreenUnlockService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }
    }
}
