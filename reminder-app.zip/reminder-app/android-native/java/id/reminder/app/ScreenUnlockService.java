package id.reminder.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.service.notification.StatusBarNotification;
import androidx.core.app.NotificationCompat;

public class ScreenUnlockService extends Service {

    private BroadcastReceiver unlockReceiver;
    private final Handler autoLaunchHandler = new Handler(Looper.getMainLooper());
    private static final String CHANNEL_ID = "reminder_service_channel";
    private static final String TRIGGER_CHANNEL_ID = "reminder_trigger_channel";
    private static final int SERVICE_NOTIF_ID = 9001;
    private static final int TRIGGER_NOTIF_ID = 9002;
    private static final long AUTO_LAUNCH_DELAY_MS = 2000;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannels();
        startForeground(SERVICE_NOTIF_ID, buildServiceNotification());

        unlockReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                if (Intent.ACTION_USER_PRESENT.equals(intent.getAction())) {
                    fireReminderNotification();
                }
            }
        };
        registerReceiver(unlockReceiver, new IntentFilter(Intent.ACTION_USER_PRESENT));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        autoLaunchHandler.removeCallbacksAndMessages(null);
        try {
            unregisterReceiver(unlockReceiver);
        } catch (Exception e) {
            // ignore
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager mgr = getSystemService(NotificationManager.class);

            NotificationChannel serviceChannel = new NotificationChannel(
                CHANNEL_ID, "Status Reminder", NotificationManager.IMPORTANCE_MIN
            );
            mgr.createNotificationChannel(serviceChannel);

            NotificationChannel triggerChannel = new NotificationChannel(
                TRIGGER_CHANNEL_ID, "Notifikasi Reminder", NotificationManager.IMPORTANCE_HIGH
            );
            mgr.createNotificationChannel(triggerChannel);
        }
    }

    private Notification buildServiceNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Reminder aktif")
            .setContentText("Memantau saat layar dibuka kunci")
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build();
    }

    /** Buat Intent untuk membuka app target, fallback ke Play Store kalau belum terinstall. */
    private Intent buildLaunchIntent(String targetPackage) {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(targetPackage);
        if (launchIntent == null) {
            launchIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + targetPackage));
        }
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return launchIntent;
    }

    private void fireReminderNotification() {
        SharedPreferences prefs = getSharedPreferences("reminder_prefs", 0);
        if (!prefs.getBoolean("enabled", false)) return;

        final String targetPackage = prefs.getString("targetPackage", "");
        String title = prefs.getString("title", "Reminder");
        String body = prefs.getString("body", "Ketuk untuk membuka aplikasi");

        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, TRIGGER_NOTIF_ID, buildLaunchIntent(targetPackage),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification notif = new NotificationCompat.Builder(this, TRIGGER_CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(body + " (otomatis terbuka dalam 2 detik)")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setFullScreenIntent(pendingIntent, true)
            .build();

        NotificationManager mgr = getSystemService(NotificationManager.class);
        mgr.notify(TRIGGER_NOTIF_ID, notif);

        // Jadwalkan auto-launch: hanya jalan kalau notifikasi masih ada
        // (artinya user belum tap ataupun swipe/dismiss notifikasinya).
        autoLaunchHandler.postDelayed(() -> autoLaunchIfStillPending(targetPackage), AUTO_LAUNCH_DELAY_MS);
    }

    private void autoLaunchIfStillPending(String targetPackage) {
        NotificationManager mgr = getSystemService(NotificationManager.class);
        boolean stillActive = false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            for (StatusBarNotification sbn : mgr.getActiveNotifications()) {
                if (sbn.getId() == TRIGGER_NOTIF_ID) {
                    stillActive = true;
                    break;
                }
            }
        }

        if (stillActive) {
            mgr.cancel(TRIGGER_NOTIF_ID);
            if (ReminderAccessibilityService.isRunning()) {
                ReminderAccessibilityService.launchApp(targetPackage);
            } else {
                startActivity(buildLaunchIntent(targetPackage));
            }
        }
        // Kalau sudah tidak ada (user sudah tap/swipe), tidak perlu apa-apa lagi.
    }
}
