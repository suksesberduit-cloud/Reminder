package id.reminder.app;

import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.util.Collections;
import java.util.List;

@CapacitorPlugin(
    name = "Reminder",
    permissions = {
        @Permission(strings = { android.Manifest.permission.POST_NOTIFICATIONS }, alias = "notifications")
    }
)
public class ReminderPlugin extends Plugin {

    @PluginMethod
    public void requestPermissions(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissionForAlias("notifications", call, "permCallback");
        } else {
            promptFullScreenIntentIfNeeded();
            call.resolve();
        }
    }

    @PermissionCallback
    private void permCallback(PluginCall call) {
        promptFullScreenIntentIfNeeded();
        call.resolve();
    }

    /**
     * Di Android 14+, aplikasi wajib diizinkan user secara eksplisit untuk pakai
     * Full-Screen Intent (mekanisme resmi yang boleh auto-buka Activity dari
     * background/lockscreen, dipakai app alarm & telepon). Kalau belum diizinkan,
     * arahkan user ke halaman Settings yang benar (cuma sekali, disimpan flagnya).
     */
    private void promptFullScreenIntentIfNeeded() {
        if (Build.VERSION.SDK_INT < 34) return;

        SharedPreferences prefs = getContext().getSharedPreferences("reminder_prefs", 0);
        if (prefs.getBoolean("fullScreenPromptShown", false)) return;

        NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
        boolean allowed = true;
        try {
            java.lang.reflect.Method m = NotificationManager.class.getMethod("canUseFullScreenIntent");
            allowed = (boolean) m.invoke(nm);
        } catch (Exception e) {
            // Method tidak tersedia / gagal dicek -> anggap sudah diizinkan
        }

        if (!allowed) {
            Intent intent = new Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT");
            intent.setData(Uri.parse("package:" + getContext().getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
        }

        prefs.edit().putBoolean("fullScreenPromptShown", true).apply();
    }

    @PluginMethod
    public void startService(PluginCall call) {
        Context ctx = getContext();
        SharedPreferences prefs = ctx.getSharedPreferences("reminder_prefs", 0);
        prefs.edit()
            .putString("targetPackage", call.getString("targetPackage", ""))
            .putString("title", call.getString("title", "Reminder"))
            .putString("body", call.getString("body", "Ketuk untuk membuka aplikasi"))
            .putBoolean("enabled", true)
            .apply();

        Intent intent = new Intent(ctx, ScreenUnlockService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(intent);
        } else {
            ctx.startService(intent);
        }
        call.resolve();
    }

    @PluginMethod
    public void stopService(PluginCall call) {
        Context ctx = getContext();
        ctx.getSharedPreferences("reminder_prefs", 0).edit()
            .putBoolean("enabled", false).apply();
        ctx.stopService(new Intent(ctx, ScreenUnlockService.class));
        call.resolve();
    }

    /**
     * Menampilkan dialog native berisi SEMUA aplikasi terinstall yang bisa dibuka
     * (punya launcher icon), diurutkan alfabetis. User tap salah satu -> resolve
     * dengan packageName + appName. User cancel (tap luar dialog) -> reject.
     */
    @PluginMethod
    public void pickInstalledApp(PluginCall call) {
        call.setKeepAlive(true);

        getActivity().runOnUiThread(() -> {
            PackageManager pm = getContext().getPackageManager();
            Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
            mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> apps = pm.queryIntentActivities(mainIntent, 0);
            Collections.sort(apps, new ResolveInfo.DisplayNameComparator(pm));

            final String[] labels = new String[apps.size()];
            final String[] packages = new String[apps.size()];
            for (int i = 0; i < apps.size(); i++) {
                ResolveInfo ri = apps.get(i);
                labels[i] = ri.loadLabel(pm).toString();
                packages[i] = ri.activityInfo.packageName;
            }

            new AlertDialog.Builder(getActivity())
                .setTitle("Pilih Aplikasi Tujuan")
                .setItems(labels, (dialog, which) -> {
                    JSObject ret = new JSObject();
                    ret.put("packageName", packages[which]);
                    ret.put("appName", labels[which]);
                    call.resolve(ret);
                })
                .setOnCancelListener(dialog -> call.reject("Dibatalkan pengguna"))
                .show();
        });
    }

    @PluginMethod
    public void isRunning(PluginCall call) {
        boolean enabled = getContext().getSharedPreferences("reminder_prefs", 0)
            .getBoolean("enabled", false);
        JSObject ret = new JSObject();
        ret.put("value", enabled);
        call.resolve(ret);
    }
}
