package id.reminder.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

@CapacitorPlugin(
    name = "Reminder",
    permissions = {
        @Permission(strings = { android.Manifest.permission.POST_NOTIFICATIONS }, alias = "notifications")
    }
)
public class ReminderPlugin extends Plugin {

    @PluginMethod
    public void requestPermissions(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissionForAlias("notifications", call, "permCallback");
        } else {
            call.resolve();
        }
    }

    @PermissionCallback
    private void permCallback(PluginCall call) {
        call.resolve();
    }

    @PluginMethod
    public void startService(PluginCall call) {
        Context ctx = getContext();
        SharedPreferences prefs = ctx.getSharedPreferences("reminder_prefs", 0);
        prefs.edit()
            .putString("targetPackage", call.getString("targetPackage", ""))
            .putString("title", call.getString("title", "Reminder"))
            .putString("body", call.getString("body", "Ketuk untuk membuka aplikasi"))
            .putBoolean("enabled", true)
            .apply();

        Intent intent = new Intent(ctx, ScreenUnlockService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(intent);
        } else {
            ctx.startService(intent);
        }
        call.resolve();
    }

    @PluginMethod
    public void stopService(PluginCall call) {
        Context ctx = getContext();
        ctx.getSharedPreferences("reminder_prefs", 0).edit()
            .putBoolean("enabled", false).apply();
        ctx.stopService(new Intent(ctx, ScreenUnlockService.class));
        call.resolve();
    }

    @PluginMethod
    public void isRunning(PluginCall call) {
        boolean enabled = getContext().getSharedPreferences("reminder_prefs", 0)
            .getBoolean("enabled", false);
        JSObject ret = new JSObject();
        ret.put("value", enabled);
        call.resolve(ret);
    }
}
