package id.reminder.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.net.Uri;
import android.view.accessibility.AccessibilityEvent;

/**
 * Service ini TIDAK membaca/menganalisa konten layar apapun (canRetrieveWindowContent
 * di config-nya sengaja diset false). Satu-satunya alasan dibuat: Accessibility Service
 * dikecualikan dari pembatasan "background activity launch" yang berlaku untuk foreground
 * service biasa, jadi bisa dipakai untuk benar-benar membuka app target secara otomatis.
 */
public class ReminderAccessibilityService extends AccessibilityService {

    private static ReminderAccessibilityService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Sengaja dikosongkan — service ini pasif, cuma dipanggil manual dari luar.
    }

    @Override
    public void onInterrupt() {
    }

    public static boolean isRunning() {
        return instance != null;
    }

    /** Dipanggil dari ScreenUnlockService untuk benar-benar membuka app target. */
    public static void launchApp(String targetPackage) {
        if (instance == null) return;

        Intent launchIntent = instance.getPackageManager().getLaunchIntentForPackage(targetPackage);
        if (launchIntent == null) {
            launchIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + targetPackage));
        }
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        instance.startActivity(launchIntent);
    }
}
