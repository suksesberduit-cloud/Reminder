package id.reminder.app

import android.content.Intent
import android.os.Build
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback

@CapacitorPlugin(
    name = "Reminder",
    permissions = [
        Permission(strings = [android.Manifest.permission.POST_NOTIFICATIONS], alias = "notifications")
    ]
)
class ReminderPlugin : Plugin() {

    @PluginMethod
    fun requestPermissions(call: PluginCall) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissionForAlias("notifications", call, "permCallback")
        } else {
            call.resolve()
        }
    }

    @PermissionCallback
    private fun permCallback(call: PluginCall) {
        call.resolve()
    }

    @PluginMethod
    fun startService(call: PluginCall) {
        val ctx = context
        val prefs = ctx.getSharedPreferences("reminder_prefs", 0)
        prefs.edit()
            .putString("targetPackage", call.getString("targetPackage", ""))
            .putString("title", call.getString("title", "Reminder"))
            .putString("body", call.getString("body", "Ketuk untuk membuka aplikasi"))
            .putBoolean("enabled", true)
            .apply()

        val intent = Intent(ctx, ScreenUnlockService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(intent)
        } else {
            ctx.startService(intent)
        }
        call.resolve()
    }

    @PluginMethod
    fun stopService(call: PluginCall) {
        val ctx = context
        ctx.getSharedPreferences("reminder_prefs", 0).edit()
            .putBoolean("enabled", false).apply()
        ctx.stopService(Intent(ctx, ScreenUnlockService::class.java))
        call.resolve()
    }

    @PluginMethod
    fun isRunning(call: PluginCall) {
        val enabled = context.getSharedPreferences("reminder_prefs", 0)
            .getBoolean("enabled", false)
        val ret = JSObject()
        ret.put("value", enabled)
        call.resolve(ret)
    }
}
