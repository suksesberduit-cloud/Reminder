package id.reminder.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * Dipicu AlarmManager tiap 15 menit. Selalu coba (re)start ScreenUnlockService --
 * kalau service memang masih hidup, ini tidak berdampak apa-apa (aman dipanggil
 * berulang). Kalau ternyata sudah dibunuh OS/OEM, ini yang menghidupkannya lagi.
 */
public class WatchdogReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        boolean enabled = context.getSharedPreferences("reminder_prefs", 0)
            .getBoolean("enabled", false);
        if (!enabled) return;

        Intent serviceIntent = new Intent(context, ScreenUnlockService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }
    }
}
